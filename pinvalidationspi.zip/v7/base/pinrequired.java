package com.pinv1.keycloakpinauthenticator;
import org.keycloak.authentication.RequiredActionContext;
import org.keycloak.authentication.RequiredActionProvider;
import org.keycloak.common.util.Time;
import jakarta.ws.rs.core.Response;
import org.keycloak.sessions.AuthenticationSessionModel;

import java.util.Collections;


public class pinrequired implements RequiredActionProvider {

    public static final String PROVIDER_ID = "pin validator ";
    private static final String USER_ATTRIBUTE = PROVIDER_ID;


    @Override
    public void evaluateTriggers(RequiredActionContext requiredActionContext) {

    }

    @Override
    public void requiredActionChallenge(RequiredActionContext context) {
        Response challenge = context.form().createForm("pin_input.ftl");
        context.challenge(challenge);
    }

    @Override
    public void processAction(RequiredActionContext context) {
        String pin = (context.getHttpRequest().getDecodedFormParameters().getFirst("pin"));
        AuthenticationSessionModel authSession = context.getAuthenticationSession();
        authSession.setAuthNote("pin", pin);

        if ("123".equals(pin)) {
            context.success();
        } else {
            Response challenge = context.form().setError("Invalid PIN. Please try again.").createForm("pin_input.ftl");
            context.challenge(challenge);
        }

    }

    @Override
    public void close() {

    }
}
