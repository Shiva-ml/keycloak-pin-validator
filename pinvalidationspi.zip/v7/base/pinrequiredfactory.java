package com.pinv1.keycloakpinauthenticator;
import org.keycloak.Config;
import org.keycloak.authentication.RequiredActionFactory;
import org.keycloak.authentication.RequiredActionProvider;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;

public class pinrequiredfactory implements RequiredActionFactory {

    private static final pinrequiredfactory SINGLETON = new pinrequiredfactory();

    @Override
    public String getDisplayText() {
        return "pin validator";
    }

    @Override
    public RequiredActionProvider create(KeycloakSession keycloakSession) {
        return (RequiredActionProvider) SINGLETON;
    }

    @Override
    public void init(Config.Scope scope) {

    }

    @Override
    public void postInit(KeycloakSessionFactory keycloakSessionFactory) {

    }

    @Override
    public void close() {

    }

    @Override
    public String getId() {
        return pinrequired.PROVIDER_ID;
    }
}