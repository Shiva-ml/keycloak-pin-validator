works perfectly in ui flow

api flow works without pin validation.